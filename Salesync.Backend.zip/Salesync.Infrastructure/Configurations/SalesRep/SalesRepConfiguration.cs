﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Salesync.Infrastructure.Modules.Identity.Entities;

namespace Salesync.Infrastructure.Configurations.SalesRep
{
    public class SalesRepConfiguration : IEntityTypeConfiguration<Domain.Modules.SalesRep.Entities.SalesRep>
    {
        public void Configure(EntityTypeBuilder<Domain.Modules.SalesRep.Entities.SalesRep> builder)
        {
            builder.ToTable("SalesReps");
            builder.HasKey(sr => sr.Id);

            builder.Property(sr => sr.SalesRepCode)
                .IsRequired()
                .HasMaxLength(15);
            builder.Property(sr => sr.Name)
                .IsRequired()
                .HasMaxLength(100);
            builder.Property(sr => sr.Phone)
                .IsRequired()
                .HasMaxLength(15);

            builder.Property(s => s.Mobile)
                .HasMaxLength(15);
            builder.Property(s => s.Email)
                .HasMaxLength(100);
            builder.Property(s => s.Address)
                .HasMaxLength(200);
            builder.Property(s => s.CategoryCode)
                .HasMaxLength(15);
            builder.Property(s => s.UserId)
                .HasMaxLength(450);
            builder.Property(s => s.CreditLimit)
                .HasPrecision(18, 2);

            // Relationships
            builder.HasOne(s => s.Branch)
                .WithMany()
                .HasForeignKey(s => s.BranchId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(s => s.Supervisor)
                .WithMany(s => s.TeamMembers)
                .HasForeignKey(s => s.SupervisorId)
                .OnDelete(DeleteBehavior.Restrict)
                .IsRequired(false);

            builder.HasMany(s => s.SalesRepRoutes)
                .WithOne(sr => sr.SalesRep)
                .HasForeignKey(sr => sr.SalesRepId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne<ApplicationUser>()
                  .WithOne()
                  .HasForeignKey<Domain.Modules.SalesRep.Entities.SalesRep>(
                      s => s.UserId)
                  .OnDelete(DeleteBehavior.Restrict)
                  .IsRequired(false);

            // Indexes
            builder.HasIndex(s => s.SalesRepCode)
                .IsUnique();

            builder.HasIndex(s => s.UserId)
                 .IsUnique()
                 .HasFilter("[UserId] IS NOT NULL");

        }
    }
}
