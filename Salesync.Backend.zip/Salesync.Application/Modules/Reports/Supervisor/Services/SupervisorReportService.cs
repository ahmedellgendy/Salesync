﻿using Microsoft.EntityFrameworkCore;
using Salesync.Application.Interfaces.Repositories;
using Salesync.Application.Modules.Reports.Common.Interfaces;
using Salesync.Application.Modules.Reports.Common.Models;
using Salesync.Application.Modules.Reports.Supervisor.Dtos;
using Salesync.Application.Modules.Reports.Supervisor.Interfaces;
using Salesync.Domain.Common.Enums.CustomerVisit;
using Salesync.Domain.Common.Enums.Sales;

namespace Salesync.Application.Modules.Reports.Supervisor.Services
{
    public class SupervisorReportService : ISupervisorReportService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IReportScopeService _reportScopeService;
        private readonly IReportQueryService _reportQueryService;


        public SupervisorReportService(
            IUnitOfWork unitOfWork,
            IReportScopeService reportScopeService,
            IReportQueryService reportQueryService)

        {
            _unitOfWork = unitOfWork;
            _reportScopeService = reportScopeService;
            _reportQueryService = reportQueryService;
        }

        public async Task<SupervisorSummaryReportDto> GetSummaryAsync(ReportFilter filter, CancellationToken cancellationToken = default)
        {
            var context = await PrepareReportContextAsync(
                filter,
                validatePagination: false,
                cancellationToken);

            var grossSales = await _reportQueryService
                .GetGrossSalesAsync(
                    context.SalesRepIds,
                    context.FromDate,
                    context.ToDateExclusive,
                    cancellationToken);

            var totalInvoices = await _reportQueryService
                .GetTotalInvoicesAsync(
                    context.SalesRepIds,
                    context.FromDate,
                    context.ToDateExclusive,
                    cancellationToken);

            var totalCollections = await _reportQueryService
                .GetTotalCollectionsAsync(
                    context.SalesRepIds,
                    context.FromDate,
                    context.ToDateExclusive,
                    cancellationToken);

            var totalReturns = await _reportQueryService
                .GetTotalReturnsAsync(
                    context.SalesRepIds,
                    context.FromDate,
                    context.ToDateExclusive,
                    cancellationToken);

            var totalVisits = await _reportQueryService
                .GetTotalVisitsAsync(
                    context.SalesRepIds,
                    context.FromDate,
                    context.ToDateExclusive,
                    cancellationToken);

            var customersVisited = await _reportQueryService
                .GetCustomersVisitedAsync(
                    context.SalesRepIds,
                    context.FromDate,
                    context.ToDateExclusive,
                    cancellationToken);

            var netSales = grossSales - totalReturns;

            return new SupervisorSummaryReportDto
            {
                FromDate = filter.FromDate,
                ToDate = filter.ToDate,

                GrossSales = grossSales,
                NetSales = netSales,

                TotalCollections = totalCollections,
                TotalReturns = totalReturns,

                TotalInvoices = totalInvoices,
                TotalVisits = totalVisits,

                ActiveSalesReps = context.SalesRepIds.Count,
                CustomersVisited = customersVisited
            };
        }

        public async Task<PagedResult<SupervisorSalesReportItemDto>> GetSalesAsync(ReportFilter filter, CancellationToken cancellationToken = default)
        {
            var context = await PrepareReportContextAsync(
                filter,
                validatePagination: true,
                cancellationToken);

            return await _reportQueryService.GetConfirmedSalesAsync(
                context.SalesRepIds,
                context.FromDate,
                context.ToDateExclusive,
                filter.PageNumber,
                filter.PageSize,
                x => new SupervisorSalesReportItemDto
                {
                    InvoiceId = x.Id,
                    InvoiceNumber = x.InvoiceNumber,
                    InvoiceDate = x.CreatedAt,

                    SalesRepId = x.SalesRepId!.Value,
                    SalesRepName = x.SalesRep != null
                        ? x.SalesRep.Name
                        : string.Empty,

                    CustomerId = x.CustomerId,
                    CustomerName = x.Customer.Name,

                    SubTotal = x.SubTotal,
                    DiscountAmount = x.DiscountAmount,
                    TaxAmount = x.TaxAmount,
                    TotalAmount = x.TotalAmount,

                    PaymentStatus = x.PaymentStatus
                },
                cancellationToken);
        }

        public async Task<PagedResult<SupervisorInvoiceReportItemDto>> GetInvoicesAsync(ReportFilter filter, CancellationToken cancellationToken = default)
        {
            var context = await PrepareReportContextAsync(
                filter,
                validatePagination: true,
                cancellationToken);

            return await _reportQueryService.GetInvoicesAsync(
                context.SalesRepIds,
                context.FromDate,
                context.ToDateExclusive,
                filter.PageNumber,
                filter.PageSize,
                x => new SupervisorInvoiceReportItemDto
                {
                    InvoiceId = x.Id,
                    InvoiceNumber = x.InvoiceNumber,
                    InvoiceDate = x.CreatedAt,

                    SalesRepId = x.SalesRepId!.Value,
                    SalesRepName = x.SalesRep != null
                        ? x.SalesRep.Name
                        : string.Empty,

                    CustomerId = x.CustomerId,
                    CustomerName = x.Customer.Name,

                    Status = x.Status,
                    PaymentStatus = x.PaymentStatus,

                    SubTotal = x.SubTotal,
                    DiscountAmount = x.DiscountAmount,
                    TaxAmount = x.TaxAmount,

                    TotalAmount = x.TotalAmount,
                    PaidAmount = x.PaidAmount,

                    RemainingAmount =
                        x.TotalAmount - x.PaidAmount
                },
                cancellationToken);
        }

        public async Task<PagedResult<SupervisorPaymentReportItemDto>> GetPaymentsAsync(ReportFilter filter, CancellationToken cancellationToken = default)
        {
            var context = await PrepareReportContextAsync(
                filter,
                validatePagination: true,
                cancellationToken);

            return await _reportQueryService.GetPaymentsAsync(
                context.SalesRepIds,
                context.FromDate,
                context.ToDateExclusive,
                filter.PageNumber,
                filter.PageSize,
                x => new SupervisorPaymentReportItemDto
                {
                    PaymentId = x.Id,
                    PaymentNumber = x.PaymentNumber,
                    PaymentDate = x.PaymentDate,

                    SalesRepId = x.SalesRepId!.Value,
                    SalesRepName = x.SalesRep != null
                        ? x.SalesRep.Name
                        : string.Empty,

                    CustomerId = x.CustomerId,
                    CustomerName = x.Customer.Name,

                    InvoiceId = x.InvoiceId,
                    InvoiceNumber = x.Invoice.InvoiceNumber,

                    Amount = x.Amount,

                    PaymentMethod = x.PaymentMethod,
                    Status = x.Status,

                    CheckNumber = x.CheckNumber,
                    CheckDueDate = x.CheckDueDate,
                    BankName = x.BankName,
                    TransactionReference = x.TransactionReference
                },
                cancellationToken);
        }

        public async Task<PagedResult<SupervisorReturnReportItemDto>> GetReturnsAsync(ReportFilter filter, CancellationToken cancellationToken = default)
        {
            var context = await PrepareReportContextAsync(
                filter,
                validatePagination: true,
                cancellationToken);

            return await _reportQueryService.GetReturnsAsync(
                context.SalesRepIds,
                context.FromDate,
                context.ToDateExclusive,
                filter.PageNumber,
                filter.PageSize,
                x => new SupervisorReturnReportItemDto
                {
                    ReturnId = x.Id,
                    ReturnNumber = x.ReturnNumber,
                    ReturnDate = x.CreatedAt,

                    SalesRepId = x.SalesRepId!.Value,
                    SalesRepName = x.SalesRep != null
                        ? x.SalesRep.Name
                        : string.Empty,

                    CustomerId = x.CustomerId,
                    CustomerName = x.Customer.Name,

                    InvoiceId = x.InvoiceId,
                    InvoiceNumber = x.Invoice.InvoiceNumber,

                    ReturnReason = x.ReturnReason,
                    Status = x.Status,

                    TotalAmount = x.TotalAmount,
                    ReasonNotes = x.ReasonNotes
                },
                cancellationToken);
        }

        public async Task<PagedResult<SupervisorVisitReportItemDto>> GetVisitsAsync(ReportFilter filter, CancellationToken cancellationToken = default)
        {
            var context = await PrepareReportContextAsync(
                filter,
                validatePagination: true,
                cancellationToken);

            return await _reportQueryService.GetVisitsAsync(
                context.SalesRepIds,
                context.FromDate,
                context.ToDateExclusive,
                filter.PageNumber,
                filter.PageSize,
                x => new SupervisorVisitReportItemDto
                {
                    VisitId = x.Id,

                    VisitDate = x.VisitDate,
                    EndTime = x.EndTime,

                    SalesRepId = x.SalesRepId,
                    SalesRepName = x.SalesRep.Name,

                    CustomerId = x.CustomerId,
                    CustomerName = x.Customer.Name,

                    RouteId = x.RouteId,

                    VisitType = x.VisitType,
                    Status = x.Status,
                    NegativeReason = x.NegativeReason,

                    InvoiceId = x.InvoiceId,
                    PaymentId = x.PaymentId,
                    InvoiceReturnId = x.InvoiceReturnId,

                    Notes = x.Notes
                },
                cancellationToken);
        }

        public async Task<IReadOnlyCollection<SalesRepPerformanceReportItemDto>> GetSalesRepPerformanceAsync(ReportFilter filter, CancellationToken cancellationToken = default)
        {
            var context = await PrepareReportContextAsync(
                filter,
                validatePagination: false,
                cancellationToken);

            var salesReps = await _unitOfWork.SalesReps
                .GetQueryable()
                .AsNoTracking()
                .Where(x =>
                    context.SalesRepIds.Contains(x.Id) &&
                    x.IsActive)
                .Select(x => new
                {
                    x.Id,
                    x.Name
                })
                .ToListAsync(cancellationToken);

            var metrics = await _reportQueryService
                .GetSalesRepMetricsAsync(
                    context.SalesRepIds,
                    context.FromDate,
                    context.ToDateExclusive,
                    cancellationToken);

            var metricsByRep = metrics
                .ToDictionary(x => x.SalesRepId);

            var result = salesReps
                .Select(rep =>
                {
                    metricsByRep.TryGetValue(
                        rep.Id,
                        out var metric);

                    var grossSales =
                        metric?.GrossSales ?? 0m;

                    var totalCollections =
                        metric?.TotalCollections ?? 0m;

                    var totalReturns =
                        metric?.TotalReturns ?? 0m;

                    var totalInvoices =
                        metric?.TotalInvoices ?? 0;

                    var totalVisits =
                        metric?.TotalVisits ?? 0;

                    var customersVisited =
                        metric?.CustomersVisited ?? 0;

                    var netSales =
                        grossSales - totalReturns;

                    var averageInvoiceValue =
                        totalInvoices == 0
                            ? 0m
                            : grossSales / totalInvoices;

                    return new SalesRepPerformanceReportItemDto
                    {
                        SalesRepId = rep.Id,
                        SalesRepName = rep.Name,

                        GrossSales = grossSales,
                        TotalCollections = totalCollections,
                        TotalReturns = totalReturns,
                        NetSales = netSales,

                        TotalInvoices = totalInvoices,
                        TotalVisits = totalVisits,
                        CustomersVisited = customersVisited,

                        AverageInvoiceValue = averageInvoiceValue
                    };
                })
                .OrderByDescending(x => x.NetSales)
                .ThenByDescending(x => x.TotalCollections)
                .ToList();

            return result;
        }

        #region Helper Methods

        private async Task<ReportExecutionContext> PrepareReportContextAsync(ReportFilter filter, bool validatePagination, CancellationToken cancellationToken)
        {
            ValidateFilter(
                filter,
                validatePagination);

            var scope = await _reportScopeService
                .GetCurrentScopeAsync(cancellationToken);

            var effectiveSalesRepIds =
                scope.AllowedSalesRepIds.ToList();

            if (filter.SalesRepId.HasValue)
            {
                var requestedSalesRepId =
                    filter.SalesRepId.Value;

                if (!scope.AllowedSalesRepIds.Contains(
                        requestedSalesRepId))
                {
                    throw new UnauthorizedAccessException(
                        "You are not allowed to access reports for this sales representative.");
                }

                effectiveSalesRepIds = new List<int>
                {
                    requestedSalesRepId
                };
            }

            var fromDate = filter.FromDate
                .ToDateTime(TimeOnly.MinValue);

            var toDateExclusive = filter.ToDate
                .AddDays(1)
                .ToDateTime(TimeOnly.MinValue);

            return new ReportExecutionContext
            {
                SalesRepIds = effectiveSalesRepIds,
                FromDate = fromDate,
                ToDateExclusive = toDateExclusive
            };
        }

        private static void ValidateFilter(ReportFilter filter, bool validatePagination)
        {
            ArgumentNullException.ThrowIfNull(filter);

            if (filter.FromDate == default)
            {
                throw new ArgumentException(
                    "FromDate is required.",
                    nameof(filter));
            }

            if (filter.ToDate == default)
            {
                throw new ArgumentException(
                    "ToDate is required.",
                    nameof(filter));
            }

            if (filter.FromDate > filter.ToDate)
            {
                throw new ArgumentException(
                    "FromDate cannot be greater than ToDate.",
                    nameof(filter));
            }

            if (!validatePagination)
                return;

            if (filter.PageNumber <= 0)
            {
                throw new ArgumentException(
                    "PageNumber must be greater than zero.",
                    nameof(filter));
            }

            if (filter.PageSize <= 0)
            {
                throw new ArgumentException(
                    "PageSize must be greater than zero.",
                    nameof(filter));
            }

            if (filter.PageSize > 100)
            {
                throw new ArgumentException(
                    "PageSize cannot be greater than 100.",
                    nameof(filter));
            }
        }

        #endregion

        #region Helper Models

        private sealed class ReportExecutionContext
        {
            public List<int> SalesRepIds { get; init; } = new();

            public DateTime FromDate { get; init; }

            public DateTime ToDateExclusive { get; init; }
        }

        #endregion
    }
}