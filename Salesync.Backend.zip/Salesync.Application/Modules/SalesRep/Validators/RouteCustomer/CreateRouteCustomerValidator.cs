﻿using FluentValidation;
using Salesync.Application.Modules.SalesRep.Dtos.RouteCustomerDto;

namespace Salesync.Application.Modules.SalesRep.Validators.RouteCustomer
{
    public class CreateRouteCustomerValidator
        : AbstractValidator<CreateRouteCustomerDto>
    {
        public CreateRouteCustomerValidator()
        {
            RuleFor(x => x.RouteId)
                .GreaterThan(0);

            RuleFor(x => x.CustomerId)
                .GreaterThan(0);

            RuleFor(x => x.VisitDays)
                .MaximumLength(100)
                .When(x => x.VisitDays != null);

            RuleFor(x => x.Notes)
                .MaximumLength(500)
                .When(x => x.Notes != null);
        }
    }
}