﻿using AutoMapper;
using FluentValidation;
using Microsoft.EntityFrameworkCore;
using Salesync.Application.Interfaces.Repositories;
using Salesync.Application.Interfaces.Services;
using Salesync.Application.Modules.Inventory.Interfaces;
using Salesync.Application.Modules.PriceLists.Interfaces;
using Salesync.Application.Modules.Sales.Dtos.Invoice;
using Salesync.Application.Modules.Sales.Interfaces;
using Salesync.Domain.Common.Enums.Inventory;
using Salesync.Domain.Common.Enums.LoadRequest;
using Salesync.Domain.Common.Enums.Sales;
using Salesync.Domain.Modules.LoadRequest.Entities;
using Salesync.Domain.Modules.Sales.Entities;

namespace Salesync.Application.Modules.Sales.Services
{
    public class InvoiceService : IInvoiceService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IValidator<CreateInvoiceDto> _createInvoiceValidator;
        private readonly ICurrentUserService _currentUser;
        private readonly IInventoryService _inventoryService;
        private readonly IPricingService _pricingService;

        public InvoiceService(
            IUnitOfWork unitOfWork,
            IMapper mapper,
            IValidator<CreateInvoiceDto> createInvoiceValidator,
            ICurrentUserService currentUser,
            IInventoryService inventoryService,
            IPricingService pricingService)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _createInvoiceValidator = createInvoiceValidator;
            _currentUser = currentUser;
            _inventoryService = inventoryService;
            _pricingService = pricingService;
        }

        public async Task<IEnumerable<InvoiceDto>> GetAllAsync()
        {
            var invoices = await _unitOfWork.Invoices
                .GetQueryable()
                .AsNoTracking()
                .Include(x => x.Customer)
                .Include(x => x.SalesRep)
                .Include(x => x.InvoiceItems)
                .Include(x => x.Payments)
                .Where(x => x.IsActive)
                .OrderByDescending(x => x.CreatedAt)
                .ToListAsync();

            var result = _mapper.Map<List<InvoiceDto>>(invoices);

            for (var i = 0; i < invoices.Count; i++)
            {
                var invoice = invoices[i];
                var dto = result[i];

                if (invoice.Customer is not null)
                {
                    dto.CustomerName = invoice.Customer.Name;
                    dto.CustomerAddress = invoice.Customer.Address;
                    dto.CustomerPhone = invoice.Customer.Phone;
                }

                if (invoice.SalesRep is not null)
                {
                    dto.SalesRepCode = invoice.SalesRep.SalesRepCode;
                    dto.SalesRepName = invoice.SalesRep.Name;
                    dto.SalesRepPhone = invoice.SalesRep.Phone;
                }
            }

            return result;
        }

        public async Task<InvoiceDto> GetByIdAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("Invalid invoice id.");

            var invoice = await _unitOfWork.Invoices
                .GetQueryable()
                .AsNoTracking()
                .Include(x => x.Customer)
                .Include(x => x.SalesRep)
                .Include(x => x.InvoiceItems)
                .Include(x => x.Payments)
                .FirstOrDefaultAsync(x =>
                    x.Id == id &&
                    x.IsActive);

            if (invoice == null)
            {
                throw new KeyNotFoundException(
                    $"Invoice with id {id} not found.");
            }

            var dto = _mapper.Map<InvoiceDto>(invoice);

            if (invoice.Customer is not null)
            {
                dto.CustomerName = invoice.Customer.Name;
                dto.CustomerAddress = invoice.Customer.Address;
                dto.CustomerPhone = invoice.Customer.Phone;
            }

            if (invoice.SalesRep is not null)
            {
                dto.SalesRepCode = invoice.SalesRep.SalesRepCode;
                dto.SalesRepName = invoice.SalesRep.Name;
                dto.SalesRepPhone = invoice.SalesRep.Phone;
            }

            return dto;
        }

        public async Task<InvoiceDto> CreateAsync(
            CreateInvoiceDto dto)
        {
            var validationResult =
                await _createInvoiceValidator.ValidateAsync(dto);

            if (!validationResult.IsValid)
            {
                throw new ValidationException(
                    validationResult.Errors);
            }

            var customer =
                await _unitOfWork.Customers
                    .GetByIdAsync(dto.CustomerId)
                ?? throw new KeyNotFoundException(
                    $"Customer with id {dto.CustomerId} not found.");

            if (!customer.IsActive)
            {
                throw new InvalidOperationException(
                    "Cannot create invoice for inactive customer.");
            }

            var warehouse =
                await _unitOfWork.Warehouses
                    .GetByIdAsync(dto.WarehouseId)
                ?? throw new KeyNotFoundException(
                    $"Warehouse with id {dto.WarehouseId} not found.");

            if (!warehouse.IsActive)
            {
                throw new InvalidOperationException(
                    "Cannot create invoice for inactive warehouse.");
            }

            if (string.IsNullOrWhiteSpace(
                    _currentUser.UserId))
            {
                throw new UnauthorizedAccessException(
                    "Current user is not authenticated.");
            }

            Salesync.Domain.Modules.SalesRep.Entities.SalesRep salesRep;

            var isSalesRepUser =
                string.Equals(
                    _currentUser.Role,
                    "SalesRep",
                    StringComparison.OrdinalIgnoreCase);

            if (isSalesRepUser)
            {
                salesRep =
                    (await _unitOfWork.SalesReps
                        .FindAsync(s =>
                            s.UserId == _currentUser.UserId &&
                            s.IsActive))
                    .FirstOrDefault()
                    ?? throw new UnauthorizedAccessException(
                        "SalesRep not found for current user.");
            }
            else
            {
                if (!dto.SalesRepId.HasValue)
                {
                    throw new InvalidOperationException(
                        "SalesRepId is required for admin or supervisor invoice creation.");
                }

                salesRep =
                    await _unitOfWork.SalesReps
                        .GetByIdAsync(dto.SalesRepId.Value)
                    ?? throw new KeyNotFoundException(
                        $"SalesRep with id {dto.SalesRepId.Value} not found.");

                if (!salesRep.IsActive)
                {
                    throw new InvalidOperationException(
                        "Cannot create invoice for inactive sales rep.");
                }
            }

            if (!dto.SalesRepSessionId.HasValue)
            {
                throw new InvalidOperationException(
                    "SalesRepSessionId is required.");
            }

            var session =
                await _unitOfWork.SalesRepSessions
                    .GetByIdAsync(
                        dto.SalesRepSessionId.Value)
                ?? throw new KeyNotFoundException(
                    $"SalesRepSession with id {dto.SalesRepSessionId.Value} not found.");

            if (!session.IsActive)
            {
                throw new InvalidOperationException(
                    "Cannot create invoice for inactive session.");
            }

            if (session.Status == DayStatus.Closed)
            {
                throw new InvalidOperationException(
                    "Cannot create invoice for a closed session.");
            }

            if (session.SalesRepId != salesRep.Id)
            {
                throw new UnauthorizedAccessException(
                    "You cannot create invoice using another sales rep's session.");
            }

            var invoice =
                _mapper.Map<Invoice>(dto);

            invoice.InvoiceNumber =
                GenerateInvoiceNumber();

            invoice.Status =
                InvoiceStatus.Draft;

            invoice.PaymentStatus =
                PaymentStatus.Pending;

            invoice.CreatedAt =
                DateTime.UtcNow;

            invoice.IsActive =
                true;

            invoice.SalesRepId =
                salesRep.Id;

            invoice.SalesRepSessionId =
                session.Id;

            invoice.InvoiceItems.Clear();

            foreach (var itemDto in dto.Items)
            {
                var product =
                    await _unitOfWork.Products
                        .GetByIdAsync(itemDto.ProductId)
                    ?? throw new KeyNotFoundException(
                        $"Product with id {itemDto.ProductId} not found.");

                if (!product.IsActive)
                {
                    throw new InvalidOperationException(
                        $"Product with id {itemDto.ProductId} is inactive.");
                }

                var unitsPerLargeUnit =
                    product.UnitsPerLargeUnit <= 0
                        ? 1
                        : product.UnitsPerLargeUnit;

                var saleSmallQuantity =
                    itemDto.SaleLargeQuantity *
                    unitsPerLargeUnit;

                var bonusSmallQuantity =
                    itemDto.BonusLargeQuantity *
                    unitsPerLargeUnit;

                if (saleSmallQuantity <= 0)
                {
                    throw new InvalidOperationException(
                        $"Quantity must be greater than zero for product {product.Name}.");
                }

                if (bonusSmallQuantity < 0)
                {
                    throw new InvalidOperationException(
                        $"Bonus quantity cannot be negative for product {product.Name}.");
                }

                // =============================================
                // CUSTOMER PRICE
                // =============================================

                // Price returned here is the SMALL UNIT price.
                var unitPrice =
                    await _pricingService.GetUnitPriceAsync(
                        dto.CustomerId,
                        product.Id);

                if (unitPrice <= 0)
                {
                    throw new InvalidOperationException(
                        $"Invalid price for product {product.Name}.");
                }

                // =============================================
                // ITEM TOTALS
                // =============================================

                var grossAmount =
                    unitPrice *
                    saleSmallQuantity;

                var itemDiscountAmount =
                    itemDto.DiscountAmount;

                if (itemDto.DiscountPercentage > 0)
                {
                    itemDiscountAmount =
                        grossAmount *
                        (itemDto.DiscountPercentage / 100m);
                }

                if (itemDiscountAmount > grossAmount)
                {
                    throw new InvalidOperationException(
                        $"Discount cannot be greater than gross amount for product {product.Name}.");
                }

                var netAmount =
                    grossAmount -
                    itemDiscountAmount;

                // =============================================
                // INVOICE ITEM SNAPSHOT
                // =============================================

                var invoiceItem =
                    new InvoiceItem
                    {
                        ProductId =
                            product.Id,

                        ProductName =
                            product.Name,

                        ItemCode =
                            product.ItemCode,

                        // Large-unit quantities entered by user
                        SaleLargeQuantity =
                            itemDto.SaleLargeQuantity,

                        BonusLargeQuantity =
                            itemDto.BonusLargeQuantity,

                        // Small-unit quantities used by stock/accounting
                        Quantity =
                            saleSmallQuantity,

                        BonusQuantity =
                            bonusSmallQuantity,

                        // Unit snapshot
                        SmallUnit =
                            string.IsNullOrWhiteSpace(
                                product.SmallUnit)
                                ? "قطعة"
                                : product.SmallUnit,

                        LargeUnit =
                            string.IsNullOrWhiteSpace(
                                product.LargeUnit)
                                ? "كرتونة"
                                : product.LargeUnit,

                        UnitsPerLargeUnit =
                            unitsPerLargeUnit,

                        // Pricing snapshot
                        UnitPrice =
                            unitPrice,

                        DiscountPercentage =
                            itemDto.DiscountPercentage,

                        DiscountAmount =
                            itemDiscountAmount,

                        NetAmount =
                            netAmount,

                        CreatedAt =
                            DateTime.UtcNow,

                        IsActive =
                            true
                    };

                invoice.InvoiceItems.Add(
                    invoiceItem);
            }

            var itemsGrossTotal =
                invoice.InvoiceItems
                    .Sum(i =>
                        i.Quantity *
                        i.UnitPrice);

            var itemsDiscountTotal =
                invoice.InvoiceItems
                    .Sum(i =>
                        i.DiscountAmount);

            var extraInvoiceDiscount =
                dto.DiscountAmount;

            invoice.SubTotal =
                itemsGrossTotal;

            invoice.DiscountAmount =
                itemsDiscountTotal +
                extraInvoiceDiscount;

            if (invoice.DiscountAmount >
                invoice.SubTotal)
            {
                throw new InvalidOperationException(
                    "Invoice discount cannot be greater than invoice subtotal.");
            }

            invoice.TotalAmount =
                invoice.SubTotal -
                invoice.DiscountAmount +
                invoice.TaxAmount;

            await _unitOfWork.Invoices
                .AddAsync(invoice);

            await _unitOfWork.CompleteAsync();

            return _mapper.Map<InvoiceDto>(
                invoice);
        }

        public async Task<InvoiceDto> UpdateAsync(
            int id,
            UpdateInvoiceDto dto)
        {
            var invoice =
                await _unitOfWork.Invoices
                    .GetByIdAsync(id)
                ?? throw new KeyNotFoundException(
                    $"Invoice with id {id} not found.");

            _mapper.Map(dto, invoice);

            invoice.UpdatedAt =
                DateTime.UtcNow;

            _unitOfWork.Invoices.Update(
                invoice);

            await _unitOfWork.CompleteAsync();

            return _mapper.Map<InvoiceDto>(
                invoice);
        }

        public async Task<InvoiceDto> ConfirmAsync(int id)
        {
            var invoice =
                await _unitOfWork.Invoices
                    .GetQueryable()
                    .Include(i =>
                        i.InvoiceItems)
                    .FirstOrDefaultAsync(i =>
                        i.Id == id);

            if (invoice == null)
            {
                throw new KeyNotFoundException(
                    $"Invoice with id {id} not found.");
            }

            if (!invoice.IsActive)
            {
                throw new InvalidOperationException(
                    "Cannot confirm inactive invoice.");
            }

            if (invoice.Status ==
                InvoiceStatus.Cancelled)
            {
                throw new InvalidOperationException(
                    "Cannot confirm a cancelled invoice.");
            }

            if (invoice.Status ==
                InvoiceStatus.Confirmed)
            {
                throw new InvalidOperationException(
                    "Invoice is already confirmed.");
            }

            if (!invoice.InvoiceItems.Any())
            {
                throw new InvalidOperationException(
                    "Cannot confirm invoice without items.");
            }

            if (invoice.TotalAmount <= 0)
            {
                throw new InvalidOperationException(
                    "Cannot confirm invoice with invalid total amount.");
            }

            if (!invoice.SalesRepId.HasValue)
            {
                throw new InvalidOperationException(
                    "Invoice is not assigned to a sales rep.");
            }

            var requiredInventory =
                invoice.InvoiceItems
                    .GroupBy(i =>
                        i.ProductId)
                    .Select(g =>
                        new
                        {
                            ProductId =
                                g.Key,

                            ProductName =
                                g.First().ProductName,

                            Quantity =
                                g.Sum(i =>
                                    i.Quantity +
                                    i.BonusQuantity)
                        })
                    .ToList();

            foreach (var item in requiredInventory)
            {
                if (item.Quantity <= 0)
                {
                    throw new InvalidOperationException(
                        $"Invalid inventory quantity for product {item.ProductName}.");
                }

                var salesRepInventory =
                    await _unitOfWork
                        .SalesRepInventories
                        .GetQueryable()
                        .FirstOrDefaultAsync(x =>
                            x.SalesRepId ==
                            invoice.SalesRepId.Value &&
                            x.ProductId ==
                            item.ProductId &&
                            x.IsActive);

                if (salesRepInventory == null)
                {
                    throw new InvalidOperationException(
                        $"No sales rep inventory found for product {item.ProductName}.");
                }

                if (salesRepInventory.Quantity <
                    item.Quantity)
                {
                    throw new InvalidOperationException(
                        $"Insufficient sales rep inventory for product {item.ProductName}. " +
                        $"Available: {salesRepInventory.Quantity}, " +
                        $"Required: {item.Quantity}.");
                }
            }

            await _unitOfWork
                .BeginTransactionAsync();

            try
            {
                foreach (var item in requiredInventory)
                {
                    await DecreaseSalesRepInventoryAsync(
                        invoice.SalesRepId.Value,
                        item.ProductId,
                        item.Quantity,
                        SalesRepInventoryMovementSource.Invoice,
                        invoice.Id,
                        invoice.InvoiceNumber,
                        $"Stock out from sales rep inventory for invoice {invoice.InvoiceNumber}");
                }

                invoice.Status =
                    InvoiceStatus.Confirmed;

                invoice.UpdatedAt =
                    DateTime.UtcNow;

                _unitOfWork.Invoices.Update(
                    invoice);

                await _unitOfWork.CompleteAsync();

                await _unitOfWork
                    .CommitTransactionAsync();

                return _mapper.Map<InvoiceDto>(
                    invoice);
            }
            catch
            {
                await _unitOfWork
                    .RollbackTransactionAsync();

                throw;
            }
        }

        public async Task CancelAsync(int id)
        {
            var invoice =
                await _unitOfWork.Invoices
                    .GetByIdAsync(id)
                ?? throw new KeyNotFoundException(
                    $"Invoice with id {id} not found.");

            if (invoice.Status ==
                InvoiceStatus.Confirmed)
            {
                throw new InvalidOperationException(
                    "Cannot cancel a confirmed invoice.");
            }

            invoice.Status =
                InvoiceStatus.Cancelled;

            invoice.UpdatedAt =
                DateTime.UtcNow;

            _unitOfWork.Invoices.Update(
                invoice);

            await _unitOfWork.CompleteAsync();
        }

        #region Helper Method

        private static string GenerateInvoiceNumber()
        {
            return $"INV-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString()[..4].ToUpper()}";
        }

        private async Task DecreaseSalesRepInventoryAsync(
            int salesRepId,
            int productId,
            int quantity,
            SalesRepInventoryMovementSource source,
            int? sourceId = null,
            string? sourceNumber = null,
            string? notes = null)
        {
            if (quantity <= 0)
            {
                throw new InvalidOperationException(
                    "Quantity must be greater than zero.");
            }

            var inventory =
                await _unitOfWork
                    .SalesRepInventories
                    .GetQueryable()
                    .FirstOrDefaultAsync(x =>
                        x.SalesRepId ==
                        salesRepId &&
                        x.ProductId ==
                        productId &&
                        x.IsActive);

            if (inventory == null)
            {
                throw new InvalidOperationException(
                    "Sales rep inventory not found.");
            }

            if (inventory.Quantity <
                quantity)
            {
                throw new InvalidOperationException(
                    "Insufficient sales rep inventory.");
            }

            inventory.Quantity -=
                quantity;

            inventory.LastUpdatedAt =
                DateTime.UtcNow;

            inventory.UpdatedAt =
                DateTime.UtcNow;

            var movement =
                new SalesRepInventoryMovement
                {
                    SalesRepId =
                        salesRepId,

                    ProductId =
                        productId,

                    Quantity =
                        quantity,

                    MovementType =
                        SalesRepInventoryMovementType.Out,

                    Source =
                        source,

                    SourceId =
                        sourceId,

                    SourceNumber =
                        sourceNumber,

                    MovementDate =
                        DateTime.UtcNow,

                    Notes =
                        notes,

                    CreatedAt =
                        DateTime.UtcNow,

                    IsActive =
                        true
                };

            _unitOfWork
                .SalesRepInventories
                .Update(inventory);

            await _unitOfWork
                .SalesRepInventoryMovements
                .AddAsync(movement);
        }

        #endregion
    }
}