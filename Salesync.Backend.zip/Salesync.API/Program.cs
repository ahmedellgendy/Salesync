using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using Salesync.API.Middleware;
using Salesync.Application;
using Salesync.Application.Common.Settings;
using Salesync.Application.Interfaces.Repositories;
using Salesync.Application.Mappings;
using Salesync.Application.Modules.MasterData.Interfaces.Services;
using Salesync.Application.Modules.MasterData.Services;
using Salesync.Application.Modules.MasterData.Validators.Customer;
using Salesync.Infrastructure.Data;
using Salesync.Infrastructure.DependencyInjection;
using Salesync.Infrastructure.Extensions;
using Salesync.Infrastructure.Repositories.Common;
using Salesync.Infrastructure.Seeds;


var builder = WebApplication.CreateBuilder(args);


// Add services to the container.

builder.Services.AddControllers()
    .ConfigureApiBehaviorOptions(options =>
    {
        options.InvalidModelStateResponseFactory = context =>
        {
            //return new BadRequestObjectResult(context.ModelState);
            var errors = context.ModelState
                .Where(e => e.Value?.Errors.Count > 0)
                .ToDictionary(
                    e => e.Key,
                    e => e.Value!.Errors.Select(x => x.ErrorMessage).ToArray()
                );

            var response = new
            {
                success = false,
                message = "Invalid request data. Please check your input.",
                data = (object?)null,
                errors = errors,
                statusCode = 400
            };

            return new BadRequestObjectResult(response);
        };
    });

builder.Services.AddInfrastructureServices(builder.Configuration);
builder.Services.AddMasterDataModule(builder.Configuration);
builder.Services.AddIdentityServices(builder.Configuration);
builder.Services.AddApplicationServices();

builder.Services.Configure<CompanySettings>(builder.Configuration.GetSection("Company"));
builder.Services.Configure<LicenseSettings>(builder.Configuration.GetSection("License"));
builder.Services.Configure<InitialAdminSettings>(builder.Configuration.GetSection("InitialAdmin"));

builder.Services.AddAutoMapper(typeof(MappingProfile));

builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddProblemDetails();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Salesync API",
        Version = "v1"
    });
});

builder.Services.AddCors(options =>
{
    options.AddPolicy("SalesyncPwaPolicy", policy =>
    {
        policy
            .WithOrigins(
                "https://localhost:7264",
                "http://localhost:5009",
                "http://192.168.137.106:7264",
                "http://salesyncpwa.runasp.net",
                "https://salesyncpwa.runasp.net")
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

var app = builder.Build();

// Seed roles
using (var scope = app.Services.CreateScope())
{
    await IdentitySeeder.SeedRolesAsync(
        scope.ServiceProvider);

    if (app.Environment.IsDevelopment())
    {
        await IdentitySeeder.SeedAdminUserAsync(
            scope.ServiceProvider);

        await IdentitySeeder.SeedSupervisorUserAsync(
            scope.ServiceProvider);

        await IdentitySeeder.SeedManagementUserAsync(
            scope.ServiceProvider);
    }
    else
    {
        await InitialAdminSeeder.SeedAsync(
            scope.ServiceProvider,
            builder.Configuration);
    }
}

// Configure pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Salesync API v1"));
}


app.UseHttpsRedirection();
app.UseCors("SalesyncPwaPolicy");
app.UseStaticFiles();
app.UseExceptionHandler();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.MapGet("/", () => Results.Ok(new
{
    service = "Salesync API",
    status = "Running",
    environment = app.Environment.EnvironmentName
}));

app.Run();